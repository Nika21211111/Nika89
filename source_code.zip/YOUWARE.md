# Restaurant Menu App

This is a React-based restaurant menu application with a Youbase backend.

## Features

- **Menu Browsing**: Browse dishes by category (horizontal scroll).
- **Product Details**: View ingredients and price.
- **Cart**: Add items to cart, adjust quantity.
- **Admin Panel**: `/admin` route for adding products and uploading images.
  - **Inline Management**: Admins can Edit, Hide, and Delete products directly from the main Menu page.
  - **Site Settings**: Admins can change the site name and logo from the Admin Panel.
  - **News Slider**: Admins can add photo/video slides to the main page carousel.
  - **Authentication**: Managed by Youbase Auth.
  - **Database**: Products and Categories stored in D1.
  - **Storage**: Images stored in R2 (via Youbase Storage).

## Tech Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS, Zustand, React Router DOM
- **Backend**: Youbase (Hono + Drizzle ORM + Cloudflare Workers)
- **Database**: SQLite (D1)
- **Storage**: R2

## Setup

1. Install dependencies: `npm install`
2. Run dev server: `npm run dev`
3. Build: `npm run build`

## Backend

The backend is located in `backend/`.
- Deploy: `cd backend && npx edgespark deploy`
- Schema: `backend/src/__generated__/db_schema.ts`
