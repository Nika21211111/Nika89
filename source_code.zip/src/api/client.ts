import { createEdgeSpark } from "@edgespark/client";
import "@edgespark/client/styles.css";

export const client = createEdgeSpark({
  baseUrl: "https://staging--pelcktqbnq2ltk86u3bt.youbase.cloud"
});
