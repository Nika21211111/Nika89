/* eslint-disable @typescript-eslint/no-explicit-any */
/// <reference types="vite/client" />

export {};