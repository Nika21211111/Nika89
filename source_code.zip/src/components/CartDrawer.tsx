import React from 'react';
import { useCartStore } from '../store/cartStore';
import { X, Minus, Plus, ShoppingBag } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const CartDrawer: React.FC = () => {
  const { items, isOpen, toggleCart, updateQuantity, removeFromCart, total } = useCartStore();

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            onClick={toggleCart}
            className="fixed inset-0 bg-black z-40"
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 h-full w-full max-w-md bg-white z-50 shadow-xl flex flex-col"
          >
            <div className="p-4 border-b flex justify-between items-center bg-white">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <ShoppingBag className="text-orange-500" />
                კალათა
              </h2>
              <button onClick={toggleCart} className="p-2 hover:bg-gray-100 rounded-full">
                <X size={24} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {items.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-gray-500 space-y-4">
                  <ShoppingBag size={64} className="text-gray-200" />
                  <p>კალათა ცარიელია</p>
                  <button 
                    onClick={toggleCart}
                    className="text-orange-500 font-medium hover:underline"
                  >
                    დაამატე კერძები
                  </button>
                </div>
              ) : (
                items.map((item) => (
                  <div key={item.id} className="flex gap-4 bg-gray-50 p-3 rounded-xl">
                    <img src={item.image} alt={item.name} className="w-20 h-20 object-cover rounded-lg" />
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <h4 className="font-bold text-gray-900">{item.name}</h4>
                        <p className="text-orange-600 font-medium">{item.price.toFixed(2)} ₾</p>
                      </div>
                      <div className="flex items-center gap-3 bg-white w-fit rounded-lg border px-2 py-1">
                        <button 
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="p-1 hover:text-orange-500"
                        >
                          <Minus size={16} />
                        </button>
                        <span className="font-medium w-4 text-center">{item.quantity}</span>
                        <button 
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="p-1 hover:text-orange-500"
                        >
                          <Plus size={16} />
                        </button>
                      </div>
                    </div>
                    <button 
                      onClick={() => removeFromCart(item.id)}
                      className="text-gray-400 hover:text-red-500 self-start"
                    >
                      <X size={20} />
                    </button>
                  </div>
                ))
              )}
            </div>

            {items.length > 0 && (
              <div className="p-4 border-t bg-white safe-area-bottom">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-gray-600">სულ:</span>
                  <span className="text-2xl font-bold text-gray-900">{total().toFixed(2)} ₾</span>
                </div>
                <button className="w-full bg-orange-500 text-white py-3 rounded-xl font-bold text-lg hover:bg-orange-600 transition-colors">
                  შეკვეთის გაფორმება
                </button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
