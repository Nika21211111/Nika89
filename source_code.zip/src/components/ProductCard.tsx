import React from 'react';
import { Product } from '../types';
import { Plus, Trash2, Eye, EyeOff, Edit2 } from 'lucide-react';
import { useCartStore } from '../store/cartStore';
import { clsx } from 'clsx';

interface ProductCardProps {
  product: Product;
  isAdmin?: boolean;
  onDelete?: (id: string) => void;
  onToggleVisibility?: (id: string, currentStatus: boolean) => void;
  onEdit?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ 
  product, 
  isAdmin, 
  onDelete, 
  onToggleVisibility, 
  onEdit 
}) => {
  const addToCart = useCartStore((state) => state.addToCart);
  const isHidden = !!product.isHidden;

  return (
    <div className={clsx(
      "bg-white rounded-2xl shadow-sm overflow-hidden border border-gray-100 flex flex-col h-full transition-opacity",
      isHidden && "opacity-60 grayscale"
    )}>
      <div className="relative h-48 w-full group">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover"
        />
        {isAdmin && (
          <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity bg-white/80 p-1 rounded-lg backdrop-blur-sm">
            <button 
              onClick={() => onEdit?.(product)}
              className="p-1.5 bg-blue-50 text-blue-600 rounded-md hover:bg-blue-100"
              title="რედაქტირება"
            >
              <Edit2 size={16} />
            </button>
            <button 
              onClick={() => onToggleVisibility?.(product.id, isHidden)}
              className={clsx(
                "p-1.5 rounded-md",
                isHidden ? "bg-gray-200 text-gray-500" : "bg-green-100 text-green-600"
              )}
              title={isHidden ? "გამოჩენა" : "დამალვა"}
            >
              {isHidden ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
            <button 
              onClick={() => onDelete?.(product.id)}
              className="p-1.5 bg-red-100 text-red-600 rounded-md hover:bg-red-200"
              title="წაშლა"
            >
              <Trash2 size={16} />
            </button>
          </div>
        )}
      </div>
      <div className="p-4 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-bold text-gray-900">{product.name}</h3>
          <span className="text-orange-600 font-bold">{product.price.toFixed(2)} ₾</span>
        </div>
        <p className="text-gray-500 text-sm mb-3 line-clamp-2 flex-grow">
          {product.description}
        </p>
        <div className="flex flex-wrap gap-1 mb-4">
          {product.ingredients.slice(0, 3).map((ing, idx) => (
            <span key={idx} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-md">
              {ing}
            </span>
          ))}
          {product.ingredients.length > 3 && (
            <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-md">
              +{product.ingredients.length - 3}
            </span>
          )}
        </div>
        <button
          onClick={() => addToCart(product)}
          className="w-full bg-orange-500 hover:bg-orange-600 text-white py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors active:scale-95"
        >
          <Plus size={18} />
          დამატება
        </button>
      </div>
    </div>
  );
};
