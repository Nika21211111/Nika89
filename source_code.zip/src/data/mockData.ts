import { Category, Product } from '../types';

export const categories: Category[] = [
  { id: '1', name: 'პოპულარული' },
  { id: '2', name: 'ხინკალი' },
  { id: '3', name: 'მწვადი' },
  { id: '4', name: 'სუპები' },
  { id: '5', name: 'სალათები' },
  { id: '6', name: 'სასმელები' },
  { id: '7', name: 'დესერტი' },
];

export const products: Product[] = [
  {
    id: '1',
    categoryId: '2',
    name: 'ხინკალი ქალაქური',
    description: 'უგემრიელესი ხინკალი საქონლის და ღორის ხორცით, მწვანილებით.',
    price: 2.50,
    image: 'https://images.unsplash.com/photo-1603082286882-6f7c5e8b0b0f?w=500&q=80',
    ingredients: ['ფქვილი', 'საქონლის ხორცი', 'ღორის ხორცი', 'ხახვი', 'ქინძი', 'წიწაკა']
  },
  {
    id: '2',
    categoryId: '2',
    name: 'ხინკალი მთიულური',
    description: 'ტრადიციული მთიულური ხინკალი ცხვრის ხორცით.',
    price: 2.50,
    image: 'https://images.unsplash.com/photo-1603082286882-6f7c5e8b0b0f?w=500&q=80',
    ingredients: ['ფქვილი', 'ცხვრის ხორცი', 'ხახვი', 'წიწაკა', 'ძირა']
  },
  {
    id: '3',
    categoryId: '3',
    name: 'მწვადი ღორის',
    description: 'ნაკვერჩხალზე შემწვარი ღორის მწვადი.',
    price: 18.00,
    image: 'https://images.unsplash.com/photo-1529193591184-b1d580690dd0?w=500&q=80',
    ingredients: ['ღორის ხორცი', 'ხახვი', 'სანელებლები']
  },
  {
    id: '4',
    categoryId: '5',
    name: 'ცეზარი ქათმით',
    description: 'კლასიკური ცეზარი შემწვარი ქათმის ფილეთი.',
    price: 15.00,
    image: 'https://images.unsplash.com/photo-1550304943-4f24f54ddde9?w=500&q=80',
    ingredients: ['სალათის ფოთლები', 'ქათმის ფილე', 'პარმეზანი', 'ორცხობილა', 'სოუსი']
  },
  {
    id: '5',
    categoryId: '6',
    name: 'კოკა-კოლა 0.5ლ',
    description: 'გამაგრილებელი სასმელი.',
    price: 3.00,
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    ingredients: ['წყალი', 'შაქარი', 'ნახშირორჟანგი', 'საღებავი']
  }
];
