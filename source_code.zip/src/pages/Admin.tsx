import React, { useState, useEffect, useRef } from 'react';
import { Layout } from '../components/Layout';
import { Image, Upload, Plus, Save, Layers, Package, Eye, EyeOff, Trash2, Edit2, Settings, Video } from 'lucide-react';
import { client } from '../api/client';
import { Category } from '../types';
import { clsx } from 'clsx';
import { useSearchParams } from 'react-router-dom';
import { useSettingsStore } from '../store/settingsStore';

export const Admin: React.FC = () => {
  const [searchParams] = useSearchParams();
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const authContainerRef = useRef<HTMLDivElement>(null);
  const [activeTab, setActiveTab] = useState<'product' | 'category' | 'settings' | 'slides'>('product');
  
  // Slides State
  const [slides, setSlides] = useState<any[]>([]);
  const [slideTitle, setSlideTitle] = useState('');
  const [slideType, setSlideType] = useState<'image' | 'video'>('image');
  const [slideFile, setSlideFile] = useState<File | null>(null);
  const [slidePreview, setSlidePreview] = useState<string | null>(null);
  
  // Settings Form State
  const { siteName, logoUrl, fetchSettings, updateSettings } = useSettingsStore();
  const [settingsName, setSettingsName] = useState(siteName);
  const [settingsLogoFile, setSettingsLogoFile] = useState<File | null>(null);
  const [settingsLogoPreview, setSettingsLogoPreview] = useState<string | null>(logoUrl);
  
  // Product Form State
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [ingredients, setIngredients] = useState<string[]>([]);
  const [newIngredient, setNewIngredient] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [existingImageUrl, setExistingImageUrl] = useState<string | null>(null);
  
  // Category Form State
  const [catName, setCatName] = useState('');
  const [catImageFile, setCatImageFile] = useState<File | null>(null);
  const [catImagePreview, setCatImagePreview] = useState<string | null>(null);

  const [categories, setCategories] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchCategories = async () => {
    try {
      const res = await client.api.fetch('/api/categories');
      if (res.ok) {
        const cats = await res.json();
        setCategories(cats.map((c: any) => ({ ...c, id: String(c.id) })));
      }
    } catch (e) {
      console.error('Failed to fetch categories', e);
    }
  };

  const fetchProducts = async () => {
    try {
      const res = await client.api.fetch('/api/products');
      if (res.ok) {
        const prods = await res.json();
        setProducts(prods.map((p: any) => ({ ...p, id: String(p.id), categoryId: String(p.categoryId) })));
      }
    } catch (e) {
      console.error('Failed to fetch products', e);
    }
  };

  const fetchSlides = async () => {
    try {
      const res = await client.api.fetch('/api/public/slides');
      if (res.ok) {
        const data = await res.json();
        setSlides(data.map((s: any) => ({ ...s, id: String(s.id) })));
      }
    } catch (e) {
      console.error('Failed to fetch slides', e);
    }
  };

  useEffect(() => {
    const init = async () => {
      const session = await client.auth.getSession();
      setUser(session.data?.user);
      setLoading(false);
      if (session.data?.user) {
        await fetchCategories();
        await fetchProducts();
        await fetchSlides();
      }
    };
    init();
  }, []);

  useEffect(() => {
    if (!loading && !user && authContainerRef.current) {
      client.auth.renderAuthUI(authContainerRef.current, {
        onLogin: (u) => {
          setUser(u);
          fetchCategories();
          fetchProducts();
          fetchSlides();
        },
      });
    }
  }, [loading, user]);

  useEffect(() => {
    const editId = searchParams.get('edit');
    if (editId && products.length > 0) {
      const productToEdit = products.find(p => p.id === editId);
      if (productToEdit) {
        editProduct(productToEdit);
      }
    }
  }, [searchParams, products]);

  const handleAddIngredient = () => {
    if (newIngredient.trim()) {
      setIngredients([...ingredients, newIngredient.trim()]);
      setNewIngredient('');
    }
  };

  const handleRemoveIngredient = (index: number) => {
    setIngredients(ingredients.filter((_, i) => i !== index));
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'product' | 'category') => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (type === 'product') {
        setImageFile(file);
        setImagePreview(URL.createObjectURL(file));
      } else {
        setCatImageFile(file);
        setCatImagePreview(URL.createObjectURL(file));
      }
    }
  };

  const uploadImage = async (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    
    const uploadRes = await client.api.fetch('/api/upload', {
      method: 'POST',
      body: formData
    });
    
    if (!uploadRes.ok) {
      const err = await uploadRes.json().catch(() => ({}));
      throw new Error(err.error || 'ფოტოს ატვირთვა ვერ მოხერხდა');
    }
    const uploadData = await uploadRes.json();
    const baseUrl = "https://staging--pelcktqbnq2ltk86u3bt.youbase.cloud";
    return `${baseUrl}${uploadData.url}`;
  };

  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!categoryId || !name || !price) {
      setError('გთხოვთ შეავსოთ სავალდებულო ველები (დასახელება, ფასი, კატეგორია)');
      return;
    }

    setSubmitting(true);
    try {
      let imageUrl = existingImageUrl || '';
      if (imageFile) {
        imageUrl = await uploadImage(imageFile);
      }

      const productData = {
        categoryId,
        name,
        description,
        price,
        image: imageUrl,
        ingredients
      };

      let res;
      if (editingProductId) {
        res = await client.api.fetch(`/api/products/${editingProductId}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(productData)
        });
      } else {
        res = await client.api.fetch('/api/products', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(productData)
        });
      }

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'ოპერაცია ვერ განხორციელდა');
      }

      alert(editingProductId ? 'პროდუქტი განახლდა!' : 'პროდუქტი დაემატა!');
      resetProductForm();
      await fetchProducts();
    } catch (error: any) {
      console.error(error);
      setError(error.message || 'დაფიქსირდა შეცდომა');
    } finally {
      setSubmitting(false);
    }
  };

  const resetProductForm = () => {
    setEditingProductId(null);
    setName('');
    setDescription('');
    setPrice('');
    setCategoryId('');
    setIngredients([]);
    setImageFile(null);
    setImagePreview(null);
    setExistingImageUrl(null);
  };

  const editProduct = (product: any) => {
    setEditingProductId(product.id);
    setName(product.name);
    setDescription(product.description || '');
    setPrice(String(product.price));
    setCategoryId(String(product.categoryId));
    setIngredients(product.ingredients || []);
    setExistingImageUrl(product.image);
    setImageFile(null);
    setImagePreview(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    setSettingsName(siteName);
    setSettingsLogoPreview(logoUrl);
  }, [siteName, logoUrl]);

  const handleSettingsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      let newLogoUrl = logoUrl;
      if (settingsLogoFile) {
        newLogoUrl = await uploadImage(settingsLogoFile);
      }
      
      await updateSettings({
        siteName: settingsName,
        logoUrl: newLogoUrl || undefined
      });
      
      alert('პარამეტრები განახლდა!');
    } catch (e) {
      console.error(e);
      alert('შეცდომა განახლებისას');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSlideSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!slideFile) {
      setError('გთხოვთ აირჩიოთ ფაილი');
      return;
    }
    setSubmitting(true);
    try {
      const url = await uploadImage(slideFile);
      const res = await client.api.fetch('/api/slides', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: slideType,
          url,
          title: slideTitle
        })
      });
      if (!res.ok) throw new Error('Failed to add slide');
      
      alert('სლაიდი დაემატა');
      setSlideTitle('');
      setSlideFile(null);
      setSlidePreview(null);
      fetchSlides();
    } catch (e) {
      console.error(e);
      alert('შეცდომა დამატებისას');
    } finally {
      setSubmitting(false);
    }
  };

  const deleteSlide = async (id: string) => {
    if (!confirm('ნამდვილად გსურთ წაშლა?')) return;
    try {
      await client.api.fetch(`/api/slides/${id}`, { method: 'DELETE' });
      fetchSlides();
    } catch (e) {
      console.error(e);
      alert('შეცდომა წაშლისას');
    }
  };

  const handleCategorySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!catName) {
      setError('კატეგორიის სახელი სავალდებულოა');
      return;
    }

    setSubmitting(true);
    try {
      let imageUrl = '';
      if (catImageFile) {
        imageUrl = await uploadImage(catImageFile);
      }

      const categoryData = {
        name: catName,
        image: imageUrl
      };

      const res = await client.api.fetch('/api/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(categoryData)
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'კატეგორიის დამატება ვერ მოხერხდა');
      }

      alert('კატეგორია წარმატებით დაემატა!');
      setCatName('');
      setCatImageFile(null);
      setCatImagePreview(null);
      await fetchCategories();
    } catch (error: any) {
      console.error(error);
      setError(error.message || 'დაფიქსირდა შეცდომა');
    } finally {
      setSubmitting(false);
    }
  };

  const toggleCategoryVisibility = async (id: string, currentHidden: boolean) => {
    try {
      await client.api.fetch(`/api/categories/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isHidden: !currentHidden })
      });
      fetchCategories();
    } catch (e) {
      console.error(e);
      alert('შეცდომა სტატუსის შეცვლისას');
    }
  };

  const deleteCategory = async (id: string) => {
    if (!confirm('ნამდვილად გსურთ წაშლა?')) return;
    try {
      await client.api.fetch(`/api/categories/${id}`, { method: 'DELETE' });
      fetchCategories();
    } catch (e) {
      console.error(e);
      alert('შეცდომა წაშლისას');
    }
  };

  const toggleProductVisibility = async (id: string, currentHidden: boolean) => {
    try {
      await client.api.fetch(`/api/products/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isHidden: !currentHidden })
      });
      fetchProducts();
    } catch (e) {
      console.error(e);
      alert('შეცდომა სტატუსის შეცვლისას');
    }
  };

  const deleteProduct = async (id: string) => {
    if (!confirm('ნამდვილად გსურთ წაშლა?')) return;
    try {
      await client.api.fetch(`/api/products/${id}`, { method: 'DELETE' });
      fetchProducts();
    } catch (e) {
      console.error(e);
      alert('შეცდომა წაშლისას');
    }
  };

  if (loading) return <div className="p-10 text-center">იტვირთება...</div>;

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white p-8 rounded-2xl shadow-lg w-full max-w-sm">
          <h2 className="text-2xl font-bold text-center mb-6 text-gray-900">ადმინ პანელი</h2>
          <div ref={authContainerRef} />
        </div>
      </div>
    );
  }

  return (
    <Layout>
      <div className="p-4">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">ადმინ პანელი</h2>
          <button 
            onClick={() => client.auth.signOut().then(() => setUser(null))}
            className="text-sm text-red-500 font-medium"
          >
            გასვლა
          </button>
        </div>

        <div className="flex gap-2 mb-6 bg-gray-100 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab('product')}
            className={clsx(
              "flex-1 py-2 rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-all",
              activeTab === 'product' ? "bg-white text-orange-500 shadow-sm" : "text-gray-500 hover:text-gray-700"
            )}
          >
            <Package size={18} />
            პროდუქტი
          </button>
          <button
            onClick={() => setActiveTab('category')}
            className={clsx(
              "flex-1 py-2 rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-all",
              activeTab === 'category' ? "bg-white text-orange-500 shadow-sm" : "text-gray-500 hover:text-gray-700"
            )}
          >
            <Layers size={18} />
            კატეგორია
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={clsx(
              "flex-1 py-2 rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-all",
              activeTab === 'settings' ? "bg-white text-orange-500 shadow-sm" : "text-gray-500 hover:text-gray-700"
            )}
          >
            <Settings size={18} />
            პარამეტრები
          </button>
          <button
            onClick={() => setActiveTab('slides')}
            className={clsx(
              "flex-1 py-2 rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-all",
              activeTab === 'slides' ? "bg-white text-orange-500 shadow-sm" : "text-gray-500 hover:text-gray-700"
            )}
          >
            <Video size={18} />
            სლაიდები
          </button>
        </div>

        {error && (
          <div className="bg-red-50 text-red-600 p-4 rounded-xl mb-4 border border-red-100">
            {error}
          </div>
        )}

        {activeTab === 'product' && (
          <div className="space-y-6">
            <form onSubmit={handleProductSubmit} className="space-y-4 bg-white p-6 rounded-2xl shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold">{editingProductId ? 'პროდუქტის რედაქტირება' : 'პროდუქტის დამატება'}</h3>
                {editingProductId && (
                  <button type="button" onClick={resetProductForm} className="text-sm text-gray-500">
                    გაუქმება
                  </button>
                )}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">დასახელება *</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-2 border rounded-xl focus:ring-2 focus:ring-orange-500 outline-none"
                  placeholder="მაგ: ხინკალი"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">აღწერა</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-4 py-2 border rounded-xl focus:ring-2 focus:ring-orange-500 outline-none h-24 resize-none"
                  placeholder="კერძის დეტალური აღწერა..."
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">ფასი (₾) *</label>
                  <input
                    type="number"
                    step="0.1"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full px-4 py-2 border rounded-xl focus:ring-2 focus:ring-orange-500 outline-none"
                    placeholder="0.00"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">კატეგორია *</label>
                  <select 
                    value={categoryId}
                    onChange={(e) => setCategoryId(e.target.value)}
                    className="w-full px-4 py-2 border rounded-xl focus:ring-2 focus:ring-orange-500 outline-none bg-white"
                    required
                  >
                    <option value="">აირჩიეთ...</option>
                    {categories.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">ინგრედიენტები</label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={newIngredient}
                    onChange={(e) => setNewIngredient(e.target.value)}
                    className="flex-1 px-4 py-2 border rounded-xl focus:ring-2 focus:ring-orange-500 outline-none"
                    placeholder="დაამატე ინგრედიენტი"
                  />
                  <button 
                    type="button" 
                    onClick={handleAddIngredient}
                    className="bg-gray-100 p-2 rounded-xl hover:bg-gray-200"
                  >
                    <Plus size={24} className="text-gray-600" />
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {ingredients.map((ing, idx) => (
                    <span key={idx} className="bg-gray-100 px-3 py-1 rounded-full text-sm text-gray-600 flex items-center gap-1">
                      {ing} <button type="button" onClick={() => handleRemoveIngredient(idx)} className="hover:text-red-500"><times/></button>
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">ფოტოს ატვირთვა</label>
                <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 flex flex-col items-center justify-center text-gray-500 hover:bg-gray-50 transition-colors cursor-pointer relative">
                  <input 
                    type="file" 
                    onChange={(e) => handleImageChange(e, 'product')}
                    className="absolute inset-0 opacity-0 cursor-pointer" 
                    accept="image/*" 
                  />
                  {imagePreview ? (
                    <img src={imagePreview} alt="Preview" className="h-32 object-contain" />
                  ) : existingImageUrl ? (
                    <img src={existingImageUrl} alt="Existing" className="h-32 object-contain" />
                  ) : (
                    <>
                      <Image size={48} className="mb-2 text-gray-400" />
                      <span className="text-sm font-medium">დააჭირეთ ან ჩააგდეთ ფოტო</span>
                      <span className="text-xs text-gray-400 mt-1">JPG, PNG (მაქს. 5MB)</span>
                    </>
                  )}
                </div>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full bg-orange-500 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-orange-600 transition-colors mt-6 disabled:opacity-50"
              >
                <Save size={20} />
                {submitting ? 'ინახება...' : (editingProductId ? 'განახლება' : 'პროდუქტის დამატება')}
              </button>
            </form>

            <div className="bg-white p-6 rounded-2xl shadow-sm">
              <h3 className="text-lg font-bold mb-4">არსებული პროდუქტები</h3>
              <div className="space-y-2">
                {products.map((prod) => (
                  <div key={prod.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                    <div className="flex items-center gap-3">
                      {prod.image ? (
                        <img src={prod.image} alt={prod.name} className="w-10 h-10 rounded-lg object-cover" />
                      ) : (
                        <div className="w-10 h-10 rounded-lg bg-gray-200 flex items-center justify-center text-gray-500">
                          <Package size={20} />
                        </div>
                      )}
                      <div>
                        <div className={clsx("font-medium", prod.isHidden && "text-gray-400 line-through")}>
                          {prod.name}
                        </div>
                        <div className="text-xs text-gray-500">{prod.price} ₾</div>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => editProduct(prod)}
                        className="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors"
                        title="რედაქტირება"
                      >
                        <Edit2 size={18} />
                      </button>
                      <button 
                        onClick={() => toggleProductVisibility(prod.id, !!prod.isHidden)}
                        className={clsx(
                          "p-2 rounded-lg transition-colors",
                          prod.isHidden ? "bg-gray-200 text-gray-500" : "bg-green-100 text-green-600"
                        )}
                        title={prod.isHidden ? "გამოჩენა" : "დამალვა"}
                      >
                        {prod.isHidden ? <EyeOff size={18} /> : <Eye size={18} />}
                      </button>
                      <button 
                        onClick={() => deleteProduct(prod.id)}
                        className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors"
                        title="წაშლა"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'category' && (
          <div className="space-y-6">
            <form onSubmit={handleCategorySubmit} className="space-y-4 bg-white p-6 rounded-2xl shadow-sm">
              <h3 className="text-lg font-bold mb-4">კატეგორიის დამატება</h3>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">კატეგორიის სახელი *</label>
                <input
                  type="text"
                  value={catName}
                  onChange={(e) => setCatName(e.target.value)}
                  className="w-full px-4 py-2 border rounded-xl focus:ring-2 focus:ring-orange-500 outline-none"
                  placeholder="მაგ: სუპები"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">აიქონი / ფოტო</label>
                <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 flex flex-col items-center justify-center text-gray-500 hover:bg-gray-50 transition-colors cursor-pointer relative">
                  <input 
                    type="file" 
                    onChange={(e) => handleImageChange(e, 'category')}
                    className="absolute inset-0 opacity-0 cursor-pointer" 
                    accept="image/*" 
                  />
                  {catImagePreview ? (
                    <img src={catImagePreview} alt="Preview" className="h-32 object-contain" />
                  ) : (
                    <>
                      <Image size={48} className="mb-2 text-gray-400" />
                      <span className="text-sm font-medium">დააჭირეთ ან ჩააგდეთ აიქონი</span>
                      <span className="text-xs text-gray-400 mt-1">JPG, PNG (მაქს. 5MB)</span>
                    </>
                  )}
                </div>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full bg-orange-500 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-orange-600 transition-colors mt-6 disabled:opacity-50"
              >
                <Save size={20} />
                {submitting ? 'ემატება...' : 'კატეგორიის დამატება'}
              </button>
            </form>

            <div className="bg-white p-6 rounded-2xl shadow-sm">
              <h3 className="text-lg font-bold mb-4">არსებული კატეგორიები</h3>
              <div className="space-y-2">
                {categories.map((cat) => (
                  <div key={cat.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                    <div className="flex items-center gap-3">
                      {cat.image ? (
                        <img src={cat.image} alt={cat.name} className="w-10 h-10 rounded-full object-cover" />
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-500">
                          <Layers size={20} />
                        </div>
                      )}
                      <span className={clsx("font-medium", cat.isHidden && "text-gray-400 line-through")}>
                        {cat.name}
                      </span>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => toggleCategoryVisibility(cat.id, !!cat.isHidden)}
                        className={clsx(
                          "p-2 rounded-lg transition-colors",
                          cat.isHidden ? "bg-gray-200 text-gray-500" : "bg-blue-100 text-blue-600"
                        )}
                        title={cat.isHidden ? "გამოჩენა" : "დამალვა"}
                      >
                        {cat.isHidden ? <EyeOff size={18} /> : <Eye size={18} />}
                      </button>
                      <button 
                        onClick={() => deleteCategory(cat.id)}
                        className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors"
                        title="წაშლა"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="space-y-6">
            <form onSubmit={handleSettingsSubmit} className="space-y-4 bg-white p-6 rounded-2xl shadow-sm">
              <h3 className="text-lg font-bold mb-4">საიტის პარამეტრები</h3>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">საიტის სახელი</label>
                <input
                  type="text"
                  value={settingsName}
                  onChange={(e) => setSettingsName(e.target.value)}
                  className="w-full px-4 py-2 border rounded-xl focus:ring-2 focus:ring-orange-500 outline-none"
                  placeholder="მაგ: გემრიელი"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">ლოგო</label>
                <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 flex flex-col items-center justify-center text-gray-500 hover:bg-gray-50 transition-colors cursor-pointer relative">
                  <input 
                    type="file" 
                    onChange={(e) => {
                      if (e.target.files?.[0]) {
                        setSettingsLogoFile(e.target.files[0]);
                        setSettingsLogoPreview(URL.createObjectURL(e.target.files[0]));
                      }
                    }}
                    className="absolute inset-0 opacity-0 cursor-pointer" 
                    accept="image/*" 
                  />
                  {settingsLogoPreview ? (
                    <img src={settingsLogoPreview} alt="Preview" className="h-32 object-contain" />
                  ) : (
                    <>
                      <Image size={48} className="mb-2 text-gray-400" />
                      <span className="text-sm font-medium">დააჭირეთ ან ჩააგდეთ ლოგო</span>
                      <span className="text-xs text-gray-400 mt-1">JPG, PNG (მაქს. 5MB)</span>
                    </>
                  )}
                </div>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full bg-orange-500 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-orange-600 transition-colors mt-6 disabled:opacity-50"
              >
                <Save size={20} />
                {submitting ? 'ინახება...' : 'შენახვა'}
              </button>
            </form>
          </div>
        )}

        {activeTab === 'slides' && (
          <div className="space-y-6">
            <form onSubmit={handleSlideSubmit} className="space-y-4 bg-white p-6 rounded-2xl shadow-sm">
              <h3 className="text-lg font-bold mb-4">სლაიდის დამატება</h3>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">სათაური (არასავალდებულო)</label>
                <input
                  type="text"
                  value={slideTitle}
                  onChange={(e) => setSlideTitle(e.target.value)}
                  className="w-full px-4 py-2 border rounded-xl focus:ring-2 focus:ring-orange-500 outline-none"
                  placeholder="მაგ: ახალი კერძები"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">ტიპი</label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="slideType"
                      value="image"
                      checked={slideType === 'image'}
                      onChange={() => setSlideType('image')}
                      className="text-orange-500 focus:ring-orange-500"
                    />
                    <span>ფოტო</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="slideType"
                      value="video"
                      checked={slideType === 'video'}
                      onChange={() => setSlideType('video')}
                      className="text-orange-500 focus:ring-orange-500"
                    />
                    <span>ვიდეო</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">ფაილი</label>
                <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 flex flex-col items-center justify-center text-gray-500 hover:bg-gray-50 transition-colors cursor-pointer relative">
                  <input 
                    type="file" 
                    onChange={(e) => {
                      if (e.target.files?.[0]) {
                        setSlideFile(e.target.files[0]);
                        setSlidePreview(URL.createObjectURL(e.target.files[0]));
                      }
                    }}
                    className="absolute inset-0 opacity-0 cursor-pointer" 
                    accept={slideType === 'image' ? "image/*" : "video/*"} 
                  />
                  {slidePreview ? (
                    slideType === 'image' ? (
                      <img src={slidePreview} alt="Preview" className="h-32 object-contain" />
                    ) : (
                      <video src={slidePreview} className="h-32 object-contain" controls />
                    )
                  ) : (
                    <>
                      {slideType === 'image' ? <Image size={48} className="mb-2 text-gray-400" /> : <Video size={48} className="mb-2 text-gray-400" />}
                      <span className="text-sm font-medium">დააჭირეთ ან ჩააგდეთ ფაილი</span>
                    </>
                  )}
                </div>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full bg-orange-500 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-orange-600 transition-colors mt-6 disabled:opacity-50"
              >
                <Save size={20} />
                {submitting ? 'ემატება...' : 'დამატება'}
              </button>
            </form>

            <div className="bg-white p-6 rounded-2xl shadow-sm">
              <h3 className="text-lg font-bold mb-4">არსებული სლაიდები</h3>
              <div className="space-y-2">
                {slides.map((slide) => (
                  <div key={slide.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                    <div className="flex items-center gap-3">
                      {slide.type === 'image' ? (
                        <img src={slide.url} alt={slide.title} className="w-16 h-10 rounded-lg object-cover" />
                      ) : (
                        <video src={slide.url} className="w-16 h-10 rounded-lg object-cover" />
                      )}
                      <div>
                        <div className="font-medium">{slide.title || '(უსათაურო)'}</div>
                        <div className="text-xs text-gray-500 uppercase">{slide.type}</div>
                      </div>
                    </div>
                    <button 
                      onClick={() => deleteSlide(slide.id)}
                      className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors"
                      title="წაშლა"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};
