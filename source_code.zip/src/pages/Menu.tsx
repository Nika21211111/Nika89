import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layout } from '../components/Layout';
import { CategoryScroller } from '../components/CategoryScroller';
import { ProductCard } from '../components/ProductCard';
import { NewsSlider } from '../components/NewsSlider';
import { client } from '../api/client';
import { Category, Product } from '../types';

export const Menu: React.FC = () => {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const init = async () => {
      try {
        const session = await client.auth.getSession();
        const currentUser = session.data?.user;
        setUser(currentUser);

        const categoryEndpoint = currentUser ? '/api/categories' : '/api/public/categories';
        const productEndpoint = currentUser ? '/api/products' : '/api/public/products';

        const [catsRes, prodsRes] = await Promise.all([
          client.api.fetch(categoryEndpoint),
          client.api.fetch(productEndpoint)
        ]);
        
        const cats = await catsRes.json();
        const prods = await prodsRes.json();
        
        setCategories(cats.map((c: any) => ({ ...c, id: String(c.id) })));
        setProducts(prods.map((p: any) => ({ ...p, id: String(p.id), categoryId: String(p.categoryId) })));
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };
    
    init();
  }, []);

  const handleToggleVisibility = async (id: string, currentHidden: boolean) => {
    if (!user) return;
    try {
      await client.api.fetch(`/api/products/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isHidden: !currentHidden })
      });
      setProducts(products.map(p => 
        p.id === id ? { ...p, isHidden: !currentHidden } : p
      ));
    } catch (e) {
      console.error(e);
      alert('შეცდომა სტატუსის შეცვლისას');
    }
  };

  const handleDelete = async (id: string) => {
    if (!user) return;
    if (!confirm('ნამდვილად გსურთ წაშლა?')) return;
    try {
      await client.api.fetch(`/api/products/${id}`, { method: 'DELETE' });
      setProducts(products.filter(p => p.id !== id));
    } catch (e) {
      console.error(e);
      alert('შეცდომა წაშლისას');
    }
  };

  const handleEdit = (product: Product) => {
    navigate(`/admin?edit=${product.id}`);
  };

  const filteredProducts = selectedCategory === 'all'
    ? products
    : products.filter(p => p.categoryId === selectedCategory);

  if (loading) {
    return (
      <Layout>
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="px-4 pt-4">
        <NewsSlider />
      </div>
      <CategoryScroller
        categories={categories}
        selectedId={selectedCategory}
        onSelect={setSelectedCategory}
      />
      
      <div className="px-4 py-6 space-y-6">
        {selectedCategory === 'all' && (
          <h2 className="text-xl font-bold text-gray-900">პოპულარული კერძები</h2>
        )}
        
        <div className="grid grid-cols-1 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard 
              key={product.id} 
              product={product}
              isAdmin={!!user}
              onDelete={handleDelete}
              onToggleVisibility={handleToggleVisibility}
              onEdit={handleEdit}
            />
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-10 text-gray-500">
            ამ კატეგორიაში კერძები არ მოიძებნა
          </div>
        )}
      </div>
    </Layout>
  );
};
