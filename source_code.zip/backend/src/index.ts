import { Hono } from "hono";
import type { Client } from "@sdk/server-types";
import { tables, buckets } from "@generated";
import { eq, desc } from "drizzle-orm";

export async function createApp(
  edgespark: Client<typeof tables>
): Promise<Hono> {
  const app = new Hono();

  // Manual bucket definition to avoid import issues
  const filesBucket = {
    bucket_name: "files",
    description: "Product images"
  };

  // Public: Get Categories (Visible Only)
  app.get('/api/public/categories', async (c) => {
    try {
      const categories = await edgespark.db.select().from(tables.categories).where(eq(tables.categories.isHidden, 0));
      return c.json(categories);
    } catch (e: any) {
      return c.json({ error: e.message }, 500);
    }
  });

  // Admin: Get All Categories
  app.get('/api/categories', async (c) => {
    try {
      const categories = await edgespark.db.select().from(tables.categories);
      return c.json(categories);
    } catch (e: any) {
      return c.json({ error: e.message }, 500);
    }
  });

  // Public: Get Products (Visible Only)
  app.get('/api/public/products', async (c) => {
    try {
      const products = await edgespark.db.select().from(tables.products).where(eq(tables.products.isHidden, 0));
      const parsedProducts = products.map((p: any) => ({
        ...p,
        ingredients: p.ingredients ? JSON.parse(p.ingredients) : []
      }));
      return c.json(parsedProducts);
    } catch (e: any) {
      return c.json({ error: e.message }, 500);
    }
  });

  // Admin: Get All Products
  app.get('/api/products', async (c) => {
    try {
      const products = await edgespark.db.select().from(tables.products);
      const parsedProducts = products.map((p: any) => ({
        ...p,
        ingredients: p.ingredients ? JSON.parse(p.ingredients) : []
      }));
      return c.json(parsedProducts);
    } catch (e: any) {
      return c.json({ error: e.message }, 500);
    }
  });

  // Public: Image Proxy
  app.get('/api/public/files/*', async (c) => {
    const path = c.req.path.replace('/api/public/files/', '');
    try {
      // @ts-ignore
      const file = await edgespark.storage.from(filesBucket).get(path);
      if (!file) return c.text('Not found', 404);
      
      // @ts-ignore
      const contentType = file.httpMetadata?.contentType || 'application/octet-stream';
      c.header('Content-Type', contentType);
      
      // @ts-ignore
      return c.body(file.body);
    } catch (e) {
      console.error('Proxy error:', e);
      return c.text('Error fetching file', 500);
    }
  });

  // Admin: Add Category
  app.post('/api/categories', async (c) => {
    try {
      const body = await c.req.json();
      const { name, image } = body;

      if (!name) {
        return c.json({ error: 'Name is required' }, 400);
      }

      const result = await edgespark.db.insert(tables.categories).values({
        name,
        image,
        isHidden: 0
      }).returning();

      return c.json(result[0]);
    } catch (e: any) {
      console.error('Error creating category:', e);
      return c.json({ error: e.message || 'Database error' }, 500);
    }
  });

  // Admin: Update Category (Visibility)
  app.patch('/api/categories/:id', async (c) => {
    try {
      const id = Number(c.req.param('id'));
      const body = await c.req.json();
      const { isHidden } = body;

      const result = await edgespark.db.update(tables.categories)
        .set({ isHidden: isHidden ? 1 : 0 })
        .where(eq(tables.categories.id, id))
        .returning();

      return c.json(result[0]);
    } catch (e: any) {
      return c.json({ error: e.message }, 500);
    }
  });

  // Admin: Delete Category
  app.delete('/api/categories/:id', async (c) => {
    try {
      const id = Number(c.req.param('id'));
      await edgespark.db.delete(tables.categories).where(eq(tables.categories.id, id));
      return c.json({ success: true });
    } catch (e: any) {
      return c.json({ error: e.message }, 500);
    }
  });

  // Admin: Add Product
  app.post('/api/products', async (c) => {
    try {
      const body = await c.req.json();
      const { categoryId, name, description, price, image, ingredients } = body;

      if (!categoryId || !name || !price) {
        return c.json({ error: 'Missing required fields' }, 400);
      }

      const result = await edgespark.db.insert(tables.products).values({
        categoryId: Number(categoryId),
        name,
        description,
        price: Number(price),
        image,
        ingredients: JSON.stringify(ingredients),
        isHidden: 0
      }).returning();

      return c.json(result[0]);
    } catch (e: any) {
      console.error('Error creating product:', e);
      return c.json({ error: e.message || 'Database error' }, 500);
    }
  });

  // Admin: Update Product
  app.patch('/api/products/:id', async (c) => {
    try {
      const id = Number(c.req.param('id'));
      const body = await c.req.json();
      
      // Extract fields to update
      const updateData: any = {};
      if (body.name !== undefined) updateData.name = body.name;
      if (body.description !== undefined) updateData.description = body.description;
      if (body.price !== undefined) updateData.price = Number(body.price);
      if (body.categoryId !== undefined) updateData.categoryId = Number(body.categoryId);
      if (body.image !== undefined) updateData.image = body.image;
      if (body.ingredients !== undefined) updateData.ingredients = JSON.stringify(body.ingredients);
      if (body.isHidden !== undefined) updateData.isHidden = body.isHidden ? 1 : 0;

      const result = await edgespark.db.update(tables.products)
        .set(updateData)
        .where(eq(tables.products.id, id))
        .returning();

      return c.json(result[0]);
    } catch (e: any) {
      return c.json({ error: e.message }, 500);
    }
  });

  // Admin: Delete Product
  app.delete('/api/products/:id', async (c) => {
    try {
      const id = Number(c.req.param('id'));
      await edgespark.db.delete(tables.products).where(eq(tables.products.id, id));
      return c.json({ success: true });
    } catch (e: any) {
      return c.json({ error: e.message }, 500);
    }
  });

  // Admin: Upload Image
  app.post('/api/upload', async (c) => {
    try {
      const body = await c.req.parseBody();
      const file = body['file'];

      console.log('Upload request received. File present:', !!file);

      if (file instanceof File) {
        const fileName = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.-]/g, '_')}`; // Sanitize filename
        const path = `products/${fileName}`;
        
        console.log('Uploading to path:', path);
        
        // @ts-ignore
        await edgespark.storage.from(filesBucket).put(path, file);
        
        console.log('Upload successful');

        return c.json({ 
          url: `/api/public/files/${path}`,
          path 
        });
      }
      
      console.error('Invalid file object:', typeof file);
      return c.json({ error: 'No file uploaded or invalid format' }, 400);
    } catch (e: any) {
      console.error('Error uploading file:', e);
      // Return detailed error for debugging
      return c.json({ error: `Upload failed: ${e.message}` }, 500);
    }
  });

  // Public: Get Settings
  app.get('/api/public/settings', async (c) => {
    try {
      const allSettings = await edgespark.db.select().from(tables.settings);
      const settingsObj = allSettings.reduce((acc: any, curr: any) => {
        acc[curr.key] = curr.value;
        return acc;
      }, {});
      return c.json(settingsObj);
    } catch (e: any) {
      return c.json({ error: e.message }, 500);
    }
  });

  // Admin: Update Settings
  app.post('/api/settings', async (c) => {
    try {
      const body = await c.req.json();
      for (const [key, value] of Object.entries(body)) {
        await edgespark.db.insert(tables.settings).values({
          key,
          value: String(value)
        }).onConflictDoUpdate({
          target: tables.settings.key,
          set: { value: String(value) }
        });
      }
      return c.json({ success: true });
    } catch (e: any) {
      return c.json({ error: e.message }, 500);
    }
  });

  // Public: Get Slides
  app.get('/api/public/slides', async (c) => {
    try {
      const allSlides = await edgespark.db.select().from(tables.slides).orderBy(desc(tables.slides.id));
      return c.json(allSlides);
    } catch (e: any) {
      return c.json({ error: e.message }, 500);
    }
  });

  // Admin: Add Slide
  app.post('/api/slides', async (c) => {
    try {
      const body = await c.req.json();
      const result = await edgespark.db.insert(tables.slides).values({
        type: body.type,
        url: body.url,
        title: body.title,
        sortOrder: 0
      }).returning();
      return c.json(result[0]);
    } catch (e: any) {
      return c.json({ error: e.message }, 500);
    }
  });

  // Admin: Delete Slide
  // Deletes a slide by ID
  app.delete('/api/slides/:id', async (c) => {
    try {
      const id = Number(c.req.param('id'));
      await edgespark.db.delete(tables.slides).where(eq(tables.slides.id, id));
      return c.json({ success: true });
    } catch (e: any) {
      return c.json({ error: e.message }, 500);
    }
  });

  return app;
}
